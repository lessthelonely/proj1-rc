void atende();
void install_alarm();
void deactivate_alarm();