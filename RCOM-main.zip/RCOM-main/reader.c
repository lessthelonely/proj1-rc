#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#define BAUDRATE B38400
#define _POSIX_SOURCE 1 /* POSIX compliant source */
#define FALSE 0
#define TRUE 1

#define SET 0x03
#define UA 0x07
#define FLAG 0x7E
#define A 0x03
#define C0 0x00
#define C1 0x40
#define RR_C0 0x05
#define RR_C1 0x85
#define REJ_C0 0x01
#define REJ_C1 0x81
#define Escape 0x7D
#define escapeFlag 0x5E
#define escapeEscape 0x5D

int trama = 0, tramaEsperado = 0;
int sizeMs = 0;
volatile int STOP = FALSE;
struct termios oldtio, newtio;

int llopen(int fd);
unsigned char *llread(int fd, int *sizeMs);
void sendControl(int fd, unsigned char control);

int main(int argc, char **argv)
{
  int fd;

//  char buf[255];

  if ((argc < 2) ||
      ((strcmp("/dev/ttyS11", argv[1]) != 0) &&
       (strcmp("/dev/ttyS4", argv[1]) != 0)))
  {
    printf("Usage:\tnserial SerialPort\n\tex: nserial /dev/ttyS1\n");
    exit(1);
  }

  /*
    Open serial port device for reading and writing and not as controlling tty
    because we don't want to get killed if linenoise sends CTRL-C.
  */

  fd = open(argv[1], O_RDWR | O_NOCTTY);
  if (fd < 0)
  {
    perror(argv[1]);
    exit(-1);
  }

 llopen(fd);
 printf("%d\n",fd);
 while (TRUE) {
   unsigned char* msReady = llread(fd, &sizeMs);
 }
 close(fd);

}

int readControl(int fd, unsigned char control)
{
  int state = 0;
  unsigned char leitura;
  while (state != 5)
  {
    printf("entrou na leitura ");
    read(fd, &leitura, 1);
    switch (state)
    {
      case 0:
      if(leitura == FLAG) {
        state = 1;
      }
      break;

      case 1:
      if(leitura == A) {
        state = 2;
      }
      else {
        if(leitura == FLAG) {
          state = 1;
        }
        else {
          state = 0;
        }
      }
      break;

      case 2:
      if (leitura == control)
      { state = 3; }
      else {
        if (leitura == FLAG)
        { state = 1; }
        else
        { state = 0; }
      }
      break;

      case 3:
      if (leitura == (A^control))
      { state = 4; }
      else {
        if(leitura == FLAG)
        { state = 1; }
        else
        { state = 0; }
      }
      break;

      case 4:
      if (leitura == FLAG)
      { state = 5; }
      else
      { state = 0; }
      break;

      default:
      return -1;
    }
  }
  return 1;
}

int llopen(int fd)
{
 if (tcgetattr(fd, &oldtio) == -1)
  { /* save current port settings */
    perror("tcgetattr");
    exit(-1);
  }

  bzero(&newtio, sizeof(newtio));
  newtio.c_cflag = BAUDRATE | CS8 | CLOCAL | CREAD;
  newtio.c_iflag = IGNPAR;
  newtio.c_oflag = 0;

  /* set input mode (non-canonical, no echo,...) */
  newtio.c_lflag = 0;

  newtio.c_cc[VTIME] = 1; /* inter-character timer unused */
  newtio.c_cc[VMIN] = 0;  /* blocking read until 5 chars received */

  /*
    VTIME e VMIN devem ser alterados de forma a proteger com um temporizador a
    leitura do(s) pr�ximo(s) caracter(es)
  */

  tcflush(fd, TCIOFLUSH);

  if (tcsetattr(fd, TCSANOW, &newtio) == -1)
  {
    perror("tcsetattr");
    exit(-1);
  }

  printf("New termios structure set\n");

  if(readControl(fd, SET))
  {
    printf("entrou no readControl \n");
    sendControl(fd,UA);
    printf("Ja mandou\n");
  }

  return TRUE;

}

unsigned char *llread(int fd, int *sizeMs) {
  unsigned char leitura, control;
  unsigned char *ms = (unsigned char *)malloc(0);
  unsigned char BCC2 = ms[0];
  int state = 0;
  bool completo = FALSE;

  while (state != 5) {
    read(fd, &leitura, 1);
    switch (state)
    {
      case 0:
      if(leitura == FLAG) {
        state = 1;
      }
      break;

      case 1:
      if(leitura == A) {
        state = 2;
      }
      else {
        if(leitura == FLAG) {
          state = 1;
        }
        else {
          state = 0;
        }
      }
      break;

      case 2:
      if (leitura == C0)
      {
        trama = 0;
        control = leitura;
        state = 3;
      }
      else if (leitura == C1){
        trama = 1;
        control = leitura;
        state = 3;
      }
      else {
        if (leitura == FLAG)
        { state = 1; }
        else
        { state = 0; }
      }
      break;

      case 3:
      if (leitura == (A^control))
      { state = 4; }
      else {
        if(leitura == FLAG)
        { state = 1; }
        else
        { state = 0; }
      }
      break;

      case 4:
      if (leitura == FLAG) {
        for (int i = 1; i < *sizeMs-1; i++)
          BCC2 ^= ms[i];

        if(BCC2 == ms[*sizeMs-1]) {
          if (trama == 0)
            sendControl(fd, RR_C1);
          else
            sendControl(fd, RR_C0);
          state = 6;
          completo = TRUE;
        }
        else {
          if (trama == 0)
            sendControl(fd, REJ_C1);
          else
            sendControl(fd, REJ_C0);
          state = 6;
          completo = FALSE;
        }
      }

      else if (leitura == Escape)
        state = 5;

      else {
        ms = (unsigned char *)realloc(ms, ++(*sizeMs));
        ms[*sizeMs-1] = leitura;
      }
      break;

      case 5:
        if (leitura == escapeFlag) {
          ms = (unsigned char *)realloc(ms, ++(*sizeMs));
          ms[*sizeMs-1] = FLAG;
        }
        else {
          if (leitura == escapeEscape) {
            ms = (unsigned char *)realloc(ms, ++(*sizeMs));
            ms[*sizeMs-1] = Escape;
          }
          else {
            perror("Character after escape character isn't valid");
            exit(-1);
          }
        }
        state = 4;
        break;
      }
    }
    ms = (unsigned char *)realloc(ms, *sizeMs-1);

    *sizeMs = *sizeMs-1;

    if (!completo)
      *sizeMs = 0;
    else {
      if (trama == tramaEsperado)
        tramaEsperado ^= 1;
      else *sizeMs = 0;
    }
    return ms;
}

void sendControl(int fd, unsigned char control)
{
  unsigned char packet[5];
  packet[0] = FLAG;
  packet[1] = A;
  packet[2] = control;
  packet[3] = A^control;
  packet[4] = FLAG;
  write(fd, packet, 5);
}
