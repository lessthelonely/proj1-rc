#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>

#define BAUDRATE B38400
#define _POSIX_SOURCE 1 /* POSIX compliant source */
#define FALSE 0
#define TRUE 1

#define SET 0x03
#define UA 0x07
#define FLAG 0x7E
#define A 0x03
#define C0 0x00
#define C1 0x40
#define CRR0 0X05
#define CRR1 0X85
#define CREJ0 0X01
#define CREJ1 0X81
#define DISC 0X0B
#define Start 0x02
#define End 0x03
#define Escape 0x7D
#define escapeFlag 0x5E
#define escapeEscape 0x5D

int Alarm = FALSE;
int alarmes = 0;
unsigned char leitura;
bool trama = TRUE;
bool leucontrolo = FALSE;
volatile int STOP = FALSE;
struct termios oldtio, newtio;

void alarmHandler()
{
  printf("Alarm=%d\n", alarmes + 1);
  Alarm = TRUE;
  alarmes++;
}

unsigned char *controlPackage(bool state, off_t fileSize, char *file, int fileNameSize, int *controlPackageSize);
unsigned char readControlMs(int fd);
int llopen(int fd);
int llwrite(int fd, unsigned char *ms, int size);

int main(int argc, char **argv)
{
  int fd, sizeCP = 0;
//  char buf[255];
//  off_t indice = 0;
  off_t fileSize;
//  unsigned char *fileData;

  if ((argc < 2) ||
      ((strcmp("/dev/ttyS10", argv[1]) != 0) &&
       (strcmp("/dev/ttyS4", argv[1]) != 0)))
  {
    printf("Usage:\tnserial SerialPort\n\tex: nserial /dev/ttyS1\n");
    exit(1);
  }

  off_t fileNameSize = strlen(argv[2]);
  struct stat st;
  stat(argv[2], &st);
  fileSize = st.st_size;

  FILE *f = fopen(argv[2], "r");
  unsigned char* fileData = (unsigned char *) malloc(fileSize);
  fread(fileData, sizeof(unsigned char), fileSize, f);

  /*
    Open serial port device for reading and writing and not as controlling tty
    because we don't want to get killed if linenoise sends CTRL-C.
  */

  fd = open(argv[1], O_RDWR | O_NOCTTY);
  if (fd < 0)
  {
    perror(argv[1]);
    exit(-1);
  }
 (void) signal(SIGALRM, alarmHandler);
 llopen(fd);
 printf("%d\n",fd);
 unsigned char *start = controlPackage(TRUE, fileSize, argv[2], fileNameSize, &sizeCP);
 llwrite(fd, fileData, fileSize);
 close(fd);
}
void sendControl(int fd, unsigned char control)
{
  unsigned char packet[5];
  packet[0]=FLAG;
  packet[1]=A;
  packet[2]=control;
  packet[3]=A^control;
  packet[4]=FLAG;
  write(fd,packet,5);
}

int readControl(int *state, unsigned char leitura, unsigned char control)
{
  switch (*state) {
    case 0:
    if(leitura == FLAG) {
      *state = 1;
    }
    break;

    case 1:
    if(leitura == A) {
      *state = 2;
    }
    else {
      if(leitura == FLAG) {
        *state = 1;
      }
      else {
        *state = 0;
      }
   }
   break;

   case 2:
   if (leitura == control) {
     *state = 3;
   }
   else {
     if(leitura == FLAG) {
       *state = 1;
     }
     else {
       *state = 0;
     }
  }
  break;

  case 3:
  if(leitura == (A^control)) {
    *state = 4;
  }
  else {
    if(leitura == FLAG) {
      *state = 1;
    }
    else {
      *state = 0;
    }
  }
  break;

  case 4:
  if (leitura == FLAG) {
    leucontrolo = TRUE;
  }
  else {
    *state = 0;
  }
  break;

  default:
  break;
 }
 return 1;
}


int llopen(int fd) {
  int state = 0;

  if (tcgetattr(fd, &oldtio) == -1)
  { /* save current port settings */
    perror("tcgetattr");
    exit(-1);
  }

  bzero(&newtio, sizeof(newtio));
  newtio.c_cflag = BAUDRATE | CS8 | CLOCAL | CREAD;
  newtio.c_iflag = IGNPAR;
  newtio.c_oflag = 0;

  /* set input mode (non-canonical, no echo,...) */
  newtio.c_lflag = 0;

  newtio.c_cc[VTIME] = 1; /* inter-character timer unused */
  newtio.c_cc[VMIN] = 0;  /* blocking read until 5 chars received */

  /*
    VTIME e VMIN devem ser alterados de forma a proteger com um temporizador a
    leitura do(s) pr�ximo(s) caracter(es)
  */

  tcflush(fd, TCIOFLUSH);

  if (tcsetattr(fd, TCSANOW, &newtio) == -1) {
    perror("tcsetattr");
    exit(-1);
  }

  printf("New termios structure set\n");

  do {
    sendControl(fd,SET);
    alarm(3);
    Alarm = FALSE;
    while (!leucontrolo && !Alarm) {
      readControl(&state, leitura, UA);
    }
 } while (alarmes < 3 && !leucontrolo);
 if (alarmes == 3)
 { return FALSE; }

 return TRUE;
}

unsigned char *controlPackage(bool state, off_t fileSize, char *file, int fileNameSize, int *controlPackageSize) {
  *controlPackageSize = 9*sizeof(unsigned char) + fileNameSize;
  unsigned char *package = (unsigned char *)malloc(*controlPackageSize);

  if (state)
    package[0] = Start;
  else
    package[0] = End;

  package[1] = 0x00;
  package[2] = 0x04;
  package[3] = (fileSize >> 24) & 0xFF;
  package[4] = (fileSize >> 16) & 0xFF;
  package[5] = (fileSize >> 8) & 0xFF;
  package[6] = fileSize & 0xFF;
  package[7] = 0x01;
  package[8] = fileNameSize;

  for (int k = 0; k < fileNameSize; k++)
    package[9+k] = file[k];

  return package;
}

int llwrite(int fd, unsigned char *ms, int size) {
  unsigned char *msFinal = (unsigned char*)malloc(sizeof(unsigned char));
  unsigned char BCC2 = ms[0];
  unsigned char *BCC2Stuffed;
  int sizeMsFinal = size+6;
  int sizeBCC2 = 1;
  bool rejected = FALSE;

  for (int i = 1; i < size; i++)
    BCC2 ^= ms[i];

  if (BCC2 == FLAG) {
    BCC2Stuffed = (unsigned char *)malloc(2 * sizeof(unsigned char *));
    BCC2Stuffed[0] = Escape;
    BCC2Stuffed[1] = escapeFlag;
    sizeBCC2++;
  }
  else {
    if (BCC2 == Escape) {
      BCC2Stuffed = (unsigned char *)malloc(2 * sizeof(unsigned char *));
      BCC2Stuffed[0] = Escape;
      BCC2Stuffed[1] = escapeEscape;
      sizeBCC2++;
    }
  }

  msFinal[0] = FLAG;
  msFinal[1] = A;
  if (trama) msFinal[2] = C0;
  else msFinal[2] = C1;

  msFinal[3] = msFinal[1] ^ msFinal[2];

  for (int i = 0, j = 4; i < size; i++) {
    if (ms[i] == FLAG) {
      msFinal = (unsigned char*)realloc(msFinal, ++sizeMsFinal);
      msFinal[j] = Escape;
      msFinal[j+1] = escapeFlag;
      j += 2;
    }
    else {
      if (ms[i] == Escape) {
        msFinal = (unsigned char*)realloc(msFinal, ++sizeMsFinal);
        msFinal[j] = Escape;
        msFinal[j+1] = escapeEscape;
        j += 2;
      }
      else {
        msFinal[j] = ms[i];
        j++;
      }
    }
    if (sizeBCC2 == 1)
      msFinal[j] = BCC2;
    else {
      msFinal = (unsigned char*)realloc(msFinal, ++sizeMsFinal);
      msFinal[j] = BCC2Stuffed[0];
      msFinal[j+1] = BCC2Stuffed[1];
      j++;
    }
    msFinal[j+1] = FLAG;
  }
    alarmes=0;
  do {
    write(fd, msFinal, sizeMsFinal);
    Alarm = FALSE;
    alarm(3);
    unsigned char leitura = readControlMs(fd);
    printf("Acabou leitura");

    if ((leitura == CRR1 && trama) || (leitura == CRR0 && !trama)) {
      rejected = FALSE;
      printf("foi lido com sucesso");
      trama = 1;
    }
    else {
      if (leitura == CREJ1 || leitura == CREJ0) {
      printf("foi lido sem sucesso");
        rejected = TRUE;
      }
      else{printf("algo estranho aconteceu");}
    }
  } while ((alarmes < 3 ));

  if (alarmes >= 3)
    return FALSE;
  else return TRUE;
}

unsigned char readControlMs(int fd) {
  int state = 0;
  unsigned char leitura;
  unsigned char returned;

  while (!Alarm || state != 5) {
    read(fd, &leitura, 1);
  switch (state)
  {
    case 0:
    printf("%c", leitura);
    if(leitura == FLAG) {
      state = 1;
    }
    break;

    case 1:
    printf("chegou ao 1\n");
    if(leitura == A) {
      state = 2;
    }
    else  {
      if(leitura == FLAG)
        { state = 1; }
      else
        { state = 0; }
    }
    break;

    case 2:
    printf("chegou ao 2\n");
    if (leitura == CRR0 || leitura == CRR1 || leitura == CREJ0 || leitura == CREJ1 || leitura == DISC || leitura == UA) {
      returned = leitura;
      state = 3;
    }
    else {
      if (leitura == FLAG)
      { state = 1; }
      else
      { state = 0; }
    }
    break;

    case 3:
    printf("chegou ao 3\n");
    if(leitura == (A^returned))
    { state = 4; }
    else state = 0;
    break;

    case 4:
    if (leitura == FLAG) {
      printf("chegou a 4\n");
       state = 5;     
      return returned;
      break;
    }
    else state = 0;
    break;

    default:
    break;
    }
  }
  return 0xFF;
}


/*

nivel aplicacao:
*le bloco de bytes do ficheiro
formata bloco para criar trama de informacao
Trama-> (D1|...|Dn)
                    2 tipos de trama:
                        1* tipo controlo (STart e END)
                        Campo controlo (1:dados;2:Start;3:End)
                        |T1 (0:tamanho;1:nome)
                        |L1 (nº de caracteres necesarios codificar no v1
                        |V1|...V2

                        2* dados
                            2* Dados
                            Campo de controlo
                            |N contador
                            |L2|L1 tamanho do que foi lido
                            k = L2x256+L1


nivel ligacao:
recebe pacote de aplicaçao e constroi trama de informacao
F!A!C!Bcc1!D1!...!Dn!Bcc2!F
c: 0 ou 1 (0x00 ou 0x40)
Bcc1
D1..Dn
Bcc2
F
-> transparencia : 0x7E -> 0x7E 0x5E
                   0x7D -> 0x7D 0x5D

Recetir: responde com RR, F!A!C!Bcc1!F
se falha envia REJ com Nr=Ns se Bcc2 errado
se Bcc1 errado nao envia nada

- controlPackage
- perguntar se é preciso dividir a mensagem
- perguntar se é preciso colocar um cabeçalho na mensagem
*/
