#ifndef STUFFING_H
#define STUFFING_H

int stuffing(u_int8_t* buffer, int length);
int destuffing(u_int8_t* buffer, int length);

#endif