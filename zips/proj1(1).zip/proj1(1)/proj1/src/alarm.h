#ifndef ALARM_H
#define ALARM_H

void atende();
void install_alarm();
void deactivate_alarm();

#endif